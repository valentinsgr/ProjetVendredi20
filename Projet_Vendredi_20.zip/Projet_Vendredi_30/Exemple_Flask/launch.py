from flask import Flask, render_template, request
import json
import pandas as pd
import matplotlib.pyplot as plt
import sklearn
from sklearn.feature_extraction.text import TfidfVectorizer,TfidfTransformer,CountVectorizer
import pickle
import numpy as np
from nltk.corpus import stopwords
from nltk.stem import SnowballStemmer
from stop_words import get_stop_words
import nltk
import re
from unidecode import unidecode

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression

app = Flask(__name__)

nltk.download('stopwords')
my_stop_word_list = get_stop_words('french')
final_stopwords_list = stopwords.words('french')


s_w=list(set(final_stopwords_list+my_stop_word_list))
s_w=[elem.lower() for elem in s_w]
fr=SnowballStemmer('french')

def nettoyage(string):
    l=[]
    string=unidecode(string.lower())
    #Sans ponctuation pour le moment
    string=" ".join(re.findall("[a-zA-Z]+", string))
    
    for word in string.split():
        #if word in s_w:
        #    continue
        #else:
            l.append(fr.stem(word))
    return ' '.join(l)
@app.route("/")
def home():
    return render_template("index.html", title='Home')

@app.route("/result",methods=['POST'])
def retour():
    user_text = request.form.get('input_text')
    print(user_text)
    return json.dumps({'text_user':user_text})

def getCom(msg):
	phrase=msg
	#Load 
	transformer = TfidfTransformer()
	loaded_vec = CountVectorizer(decode_error="replace",vocabulary=pickle.load(open("feature.pkl", "rb")))
	user = transformer.fit_transform(loaded_vec.fit_transform([nettoyage(phrase)]))

	cls=pickle.load(open("cls.pkl", "rb"))

	cls.predict(user),cls.predict_proba(user).max(),
	print(cls.predict(user))
	if cls.predict(user) >= 1:
		return 'Très bon acteur'		
	else :
		return 'Acteur pas ouf'

@app.route("/prediction",methods=['POST'])
def retour2():
    user_text = request.form.get('input_text')
    return getCom(user_text)

@app.route("/entrainement",methods=['GET','POST'])
def retour3():
	a=train()
	return json.dumps({'Accuracy':a})



def train():
	df=pd.read_csv('movies.csv',encoding='latin-1')
	len(df),len(df.drop_duplicates('star'))
	df['l_star']=df['star'].apply(lambda x:len(x.split(' ')))
	df[(df['score']<6.5) & (df['l_star']>1)].describe()
	len(df[(df['score']>6.5) & (df['l_star']>1)]),len(df[(df['score']<6.5)  & (df['l_star']>1)])
	df=df[df['l_star']>1]
	len(df[df['score']>6.5]),len(df[df['score']<6.5])
	df['label']=df['score']

	# Je conserve autant de comments par label que possible (contraint equilibrer les classes 0 et 1)

	positif=df[df['label']>=6.5].sample(391)
	#positif.index=list(range(0,len(positif)))

	negatif=df[df['label']<6.5]
	#negatif.index=list(range(len(positif),len(negatif)+len(positif)))

	Corpus=pd.concat([positif,negatif],ignore_index=True)[['star','label']]
	for ind in Corpus['label'].index:
		if Corpus.loc[ind,'label'] >= 6.5:
			Corpus.loc[ind,'label']=1
		elif Corpus.loc[ind,'label'] < 6.5:
			Corpus.loc[ind,'label']=0
        
	Corpus.label.value_counts()

	fr = SnowballStemmer('french')
	my_stop_word_list = get_stop_words('french')
	final_stopwords_list = stopwords.words('french')

	s_w=list(set(final_stopwords_list+my_stop_word_list))
	s_w=[elem.lower() for elem in s_w]


	nettoyage(Corpus['star'].loc[1])
	Corpus['star_net']=Corpus['star'].apply(nettoyage)

	vectorizer = TfidfVectorizer()
	vectorizer.fit(Corpus['star_net'])
	X=vectorizer.transform(Corpus['star_net'])

	#Save vectorizer.vocabulary_
	pickle.dump(vectorizer.vocabulary_,open("feature.pkl","wb"))
	
	
	y=Corpus['label']
	X.shape
	x_train, x_val, y_train, y_val = train_test_split(X, y, test_size = 0.2)
	cls=LogisticRegression(max_iter=300).fit(x_train,y_train)
	pickle.dump(cls,open("cls.pkl","wb"))

	print(len(vectorizer.get_feature_names()))
	return cls.score(x_val,y_val) 
	

if __name__ == "__main__":
	app.run(debug=True)
	# debug = True
